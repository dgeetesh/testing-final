export class UserService {
  user = {
    name: 'Geetesh'
  };
}
